import React, { useState, useRef } from 'react';
import { Upload, Download, Image as ImageIcon, Trash2 } from 'lucide-react';

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setProcessedImage(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeBackground = async () => {
    if (!selectedImage) return;

    setLoading(true);
    setError(null);

    try {
      // Convert base64 to blob
      const base64Data = selectedImage.split(',')[1];
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'image/png' });

      // Create form data
      const formData = new FormData();
      formData.append('image_file', blob);

      // Make API request
      const response = await fetch('https://api.remove.bg/v1.0/removebg', {
        method: 'POST',
        headers: {
          'X-Api-Key': '8zm4oYJuCABZ4mUxTfZGs4yo'
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to remove background');
      }

      // Convert response to blob and then to base64
      const resultBlob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        setProcessedImage(reader.result as string);
      };
      reader.readAsDataURL(resultBlob);
    } catch (err) {
      setError('Failed to process image. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const resetImages = () => {
    setSelectedImage(null);
    setProcessedImage(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">
              Background Remover
            </h1>
            <p className="text-gray-600">
              Upload an image and we'll remove the background for you
            </p>
          </div>

          {/* Main Content */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            {/* Upload Section */}
            <div className="mb-8">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
              >
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-12 h-12 text-gray-400 mb-4" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag
                    and drop
                  </p>
                  <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                </div>
              </label>
            </div>

            {/* Image Preview Section */}
            {selectedImage && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Original Image */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                      <ImageIcon className="w-5 h-5" />
                      Original Image
                    </h3>
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
                      <img
                        src={selectedImage}
                        alt="Original"
                        className="w-full h-full object-contain"
                      />
                    </div>
                  </div>

                  {/* Processed Image */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                      <ImageIcon className="w-5 h-5" />
                      Processed Image
                    </h3>
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
                      {processedImage ? (
                        <img
                          src={processedImage}
                          alt="Processed"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full text-gray-400">
                          {loading ? (
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
                          ) : (
                            <p>Process the image to see results</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-4 justify-center">
                  <button
                    onClick={removeBackground}
                    disabled={loading}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {loading ? (
                      'Processing...'
                    ) : (
                      <>
                        <ImageIcon className="w-5 h-5" />
                        Remove Background
                      </>
                    )}
                  </button>
                  {processedImage && (
                    <a
                      href={processedImage}
                      download="processed-image.png"
                      className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                    >
                      <Download className="w-5 h-5" />
                      Download Result
                    </a>
                  )}
                  <button
                    onClick={resetImages}
                    className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
                  >
                    <Trash2 className="w-5 h-5" />
                    Reset
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="text-red-500 text-center mt-4">{error}</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;